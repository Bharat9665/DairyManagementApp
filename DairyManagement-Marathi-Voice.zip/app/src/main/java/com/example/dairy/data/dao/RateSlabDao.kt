package com.example.dairy.data.dao

import androidx.room.*
import com.example.dairy.data.entity.RateSlab
import kotlinx.coroutines.flow.Flow

@Dao
interface RateSlabDao {
    @Query("SELECT * FROM rate_slabs ORDER BY minFat, minSnf")
    fun all(): Flow<List<RateSlab>>

    @Query("SELECT * FROM rate_slabs ORDER BY minFat, minSnf")
    suspend fun list(): List<RateSlab>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(s: RateSlab): Long

    @Delete
    suspend fun delete(s: RateSlab)
}