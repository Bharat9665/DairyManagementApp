package com.example.dairy.data.dao

import androidx.room.*
import com.example.dairy.data.entity.MilkCollection
import kotlinx.coroutines.flow.Flow

@Dao
interface MilkCollectionDao {
    @Query("SELECT * FROM collections WHERE farmerId=:farmerId ORDER BY date DESC")
    fun forFarmer(farmerId: Long): Flow<List<MilkCollection>>

    @Query("SELECT * FROM collections WHERE date BETWEEN :start AND :end ORDER BY date DESC")
    fun between(start: Long, end: Long): Flow<List<MilkCollection>>

    @Query("SELECT * FROM collections WHERE date BETWEEN :start AND :end AND farmerId=:farmerId ORDER BY date DESC")
    suspend fun listForFarmer(start: Long, end: Long, farmerId: Long): List<MilkCollection>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entry: MilkCollection): Long
}