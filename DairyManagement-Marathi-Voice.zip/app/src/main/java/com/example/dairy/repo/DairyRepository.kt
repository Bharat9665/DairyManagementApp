package com.example.dairy.repo

import com.example.dairy.data.AppDatabase
import com.example.dairy.data.entity.*

class DairyRepository(private val db: AppDatabase) {
    fun farmers() = db.farmerDao().getAll()
    suspend fun upsertFarmer(f: Farmer) = db.farmerDao().upsert(f)
    suspend fun deleteFarmer(f: Farmer) = db.farmerDao().delete(f)

    fun collectionsFor(farmerId: Long) = db.collectionDao().forFarmer(farmerId)
    fun collectionsBetween(start: Long, end: Long) = db.collectionDao().between(start, end)
    suspend fun addCollection(c: MilkCollection) = db.collectionDao().insert(c)

    fun paymentsFor(farmerId: Long) = db.paymentDao().forFarmer(farmerId)
    suspend fun addPayment(p: Payment) = db.paymentDao().insert(p)

    fun rateSlabs() = db.rateSlabDao().all()
    suspend fun saveRateSlab(s: RateSlab) = db.rateSlabDao().upsert(s)
    suspend fun deleteRateSlab(s: RateSlab) = db.rateSlabDao().delete(s)

    // One-shot lists for backup/statement
    suspend fun listCollectionsForFarmer(start: Long, end: Long, farmerId: Long) =
        db.collectionDao().listForFarmer(start, end, farmerId)
    suspend fun listPaymentsForFarmer(start: Long, end: Long, farmerId: Long) =
        db.paymentDao().listForFarmer(start, end, farmerId)
    suspend fun listFarmers() = db.farmerDao().list()
    suspend fun listRateSlabs() = db.rateSlabDao().list()
}