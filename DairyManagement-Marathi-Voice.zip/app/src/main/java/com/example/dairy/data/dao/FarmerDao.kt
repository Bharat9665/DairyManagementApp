package com.example.dairy.data.dao

import androidx.room.*
import com.example.dairy.data.entity.Farmer
import kotlinx.coroutines.flow.Flow

@Dao
interface FarmerDao {
    @Query("SELECT * FROM farmers ORDER BY name")
    fun getAll(): Flow<List<Farmer>>

    @Query("SELECT * FROM farmers ORDER BY name")
    suspend fun list(): List<Farmer>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(farmer: Farmer): Long

    @Delete
    suspend fun delete(farmer: Farmer)
}