package com.example.dairy.data.entity

import androidx.room.*
import kotlinx.serialization.Serializable

@Entity(
    tableName = "collections",
    foreignKeys = [
        ForeignKey(
            entity = Farmer::class,
            parentColumns = ["id"],
            childColumns = ["farmerId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("farmerId"), Index("date")]
)
@Serializable
data class MilkCollection(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val farmerId: Long,
    val date: Long,
    val shift: String,
    val fat: Double = 0.0,
    val snf: Double = 0.0,
    val litres: Double
)