
package com.example.dairy.ui.screens

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.dairy.data.entity.Farmer
import com.example.dairy.vm.DairyViewModel
import java.util.*

@Composable
fun CollectionsScreen(vm: DairyViewModel) {
    val farmers by vm.farmers.collectAsState()
    val context = LocalContext.current
    var selected: Farmer? by remember { mutableStateOf(null) }

    var litres by remember { mutableStateOf("") }
    var fat by remember { mutableStateOf("3.5") }
    var snf by remember { mutableStateOf("8.5") }
    var shift by remember { mutableStateOf("Morning") }

    var idx by remember { mutableStateOf(0) }
    if (farmers.isNotEmpty()) selected = farmers.getOrNull(idx)

    val rate = run {
        val f = fat.toDoubleOrNull() ?: 0.0
        val s = snf.toDoubleOrNull() ?: 0.0
        val base = selected?.ratePerLitre ?: 0.0
        vm.computeRate(f, s, base)
    }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (!granted) Toast.makeText(context, "मायक्रोफोनची परवानगी दिली पाहिजे", Toast.LENGTH_SHORT).show()
    }

    val litresLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val matches = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val text = matches?.getOrNull(0) ?: ""
            val num = text.filter { it.isDigit() || it=='.' }
            if (num.isNotBlank()) litres = num
        }
    }
    val fatLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val matches = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val text = matches?.getOrNull(0) ?: ""
            val num = text.filter { it.isDigit() || it=='.' }
            if (num.isNotBlank()) fat = num
        }
    }
    val snfLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val matches = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val text = matches?.getOrNull(0) ?: ""
            val num = text.filter { it.isDigit() || it=='.' }
            if (num.isNotBlank()) snf = num
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("दूध संकलन एंट्री")
        if (farmers.isNotEmpty()) {
            Text("शेतकरी: ${'$'}{selected?.name ?: farmers.first().name}")
            Slider(value = idx.toFloat(), onValueChange = { idx = it.toInt().coerceIn(0, farmers.lastIndex) }, valueRange = 0f..farmers.lastIndex.toFloat())
        } else Text("कृपया आधी शेतकरी जोडा")

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(litres, { litres = it }, label = { Text("लिटर") }, modifier = Modifier.weight(1f))
            IconButton(onClick = {
                permLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
                    putExtra(RecognizerIntent.EXTRA_PROMPT, "लिटर बोला")
                }
                litresLauncher.launch(intent)
            }) { Icon(Icons.Default.Mic, contentDescription = "voice") }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(fat, { fat = it }, label = { Text("फॅट %") }, modifier = Modifier.weight(1f))
            IconButton(onClick = {
                permLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "mr-IN")
                    putExtra(RecognizerIntent.EXTRA_PROMPT, "फॅट टक्का बोला")
                }
                fatLauncher.launch(intent)
            }) { Icon(Icons.Default.Mic, contentDescription = "voice") }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(snf, { snf = it }, label = { Text("SNF %") }, modifier = Modifier.weight(1f))
            IconButton(onClick = {
                permLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "mr-IN")
                    putExtra(RecognizerIntent.EXTRA_PROMPT, "SNF टक्का बोला")
                }
                snfLauncher.launch(intent)
            }) { Icon(Icons.Default.Mic, contentDescription = "voice") }
        }
        OutlinedTextField(shift, { shift = it }, label = { Text("शिफ्ट (Morning/Evening)") })
        Text("Rate: ₹${'$'}rate/L")
        Text("Estimate: ₹${'$'}{(litres.toDoubleOrNull()?:0.0) * rate}")

        Button(onClick = {
            val l = litres.toDoubleOrNull() ?: return@Button
            val f = fat.toDoubleOrNull() ?: 0.0
            val s = snf.toDoubleOrNull() ?: 0.0
            val farmerId = selected?.id ?: return@Button
            vm.addCollection(farmerId, Date().time, shift, f, s, l)
            litres = ""
        }) { Text("सेव्ह") }
    }
}
