package com.example.dairy.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Entity(tableName = "rate_slabs")
@Serializable
data class RateSlab(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val minFat: Double,
    val maxFat: Double,
    val minSnf: Double,
    val maxSnf: Double,
    val ratePerLitre: Double
)