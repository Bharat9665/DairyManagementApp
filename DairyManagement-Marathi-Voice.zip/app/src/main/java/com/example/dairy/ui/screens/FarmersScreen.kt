
package com.example.dairy.ui.screens

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.dairy.vm.DairyViewModel

@Composable
fun FarmersScreen(vm: DairyViewModel) {
    val farmers by vm.farmers.collectAsState()
    val context = LocalContext.current

    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var village by remember { mutableStateOf("") }
    var rate by remember { mutableStateOf("34.0") }

    // Permission launcher
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (!granted) Toast.makeText(context, "मायक्रोफोनची परवानगी दिली पाहिजे", Toast.LENGTH_SHORT).show()
    }

    // Speech launcher
    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val matches = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val text = matches?.getOrNull(0) ?: ""
            // where to put depends on request code stored in a state - for simplicity use lastField state
            // handled below by updating the corresponding variable
        }
    }

    // We'll use a small helper to launch speech for a target setter
    fun launchSpeech(languageTag: String = "mr-IN", onResult: (String)->Unit) {
        // ask permission first
        permLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "भाषणासाठी बोला...")
        }
        speechLauncher.launch(intent)
        // The result handler above can't directly know which field — so instead use a local one-shot launcher per field below.
    }

    // To make result mapping clean, create per-field launchers:
    val nameLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val matches = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val text = matches?.getOrNull(0) ?: ""
            name = text
        }
    }
    val phoneLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val matches = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val text = matches?.getOrNull(0) ?: ""
            phone = text.filter { it.isDigit() || it=='+' || it==' ' }
        }
    }
    val villageLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val matches = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val text = matches?.getOrNull(0) ?: ""
            village = text
        }
    }
    val rateLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val matches = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val text = matches?.getOrNull(0) ?: ""
            // extract numbers
            val num = text.filter { it.isDigit() || it=='.' }
            if (num.isNotBlank()) rate = num
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("शेतकरी नोंदणी")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(name, { name = it }, label = { Text("नाव") }, modifier = Modifier.weight(1f))
            IconButton(onClick = {
                permLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "mr-IN")
                    putExtra(RecognizerIntent.EXTRA_PROMPT, "नाव बोलून सांगाः")
                }
                nameLauncher.launch(intent)
            }) { Icon(Icons.Default.Mic, contentDescription = "voice") }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(phone, { phone = it }, label = { Text("मोबाइल") }, modifier = Modifier.weight(1f))
            IconButton(onClick = {
                permLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN") // digits often recognized better in en
                    putExtra(RecognizerIntent.EXTRA_PROMPT, "मोबाइल नंबर बोला")
                }
                phoneLauncher.launch(intent)
            }) { Icon(Icons.Default.Mic, contentDescription = "voice") }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(village, { village = it }, label = { Text("गाव") }, modifier = Modifier.weight(1f))
            IconButton(onClick = {
                permLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "mr-IN")
                    putExtra(RecognizerIntent.EXTRA_PROMPT, "गाव बोला")
                }
                villageLauncher.launch(intent)
            }) { Icon(Icons.Default.Mic, contentDescription = "voice") }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(rate, { rate = it }, label = { Text("दर (₹/L)") }, modifier = Modifier.weight(1f))
            IconButton(onClick = {
                permLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
                    putExtra(RecognizerIntent.EXTRA_PROMPT, "दर बोला")
                }
                rateLauncher.launch(intent)
            }) { Icon(Icons.Default.Mic, contentDescription = "voice") }
        }
        Button(onClick = {
            val r = rate.toDoubleOrNull() ?: 0.0
            if (name.isNotBlank()) vm.addOrUpdateFarmer(name.trim(), phone.ifBlank { null }, village.ifBlank { null }, r)
            name = ""; phone = ""; village = ""; rate = "34.0"
        }) { Text("सेव्ह") }

        Divider()
        Text("नोंदवलेले शेतकरी")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(farmers) { f ->
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text(f.name, style = MaterialTheme.typography.titleMedium)
                        Text("दर: ₹${f.ratePerLitre}/L")
                        if (!f.village.isNullOrBlank()) Text("गाव: ${f.village}")
                        if (!f.phone.isNullOrBlank()) Text("मोबाइल: ${f.phone}")
                    }
                }
            }
        }
    }
}
