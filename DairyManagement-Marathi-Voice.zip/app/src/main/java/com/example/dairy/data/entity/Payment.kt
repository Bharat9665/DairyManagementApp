package com.example.dairy.data.entity

import androidx.room.*
import kotlinx.serialization.Serializable

@Entity(
    tableName = "payments",
    foreignKeys = [
        ForeignKey(
            entity = Farmer::class,
            parentColumns = ["id"],
            childColumns = ["farmerId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("farmerId"), Index("date")]
)
@Serializable
data class Payment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val farmerId: Long,
    val date: Long,
    val amount: Double,
    val note: String? = null
)