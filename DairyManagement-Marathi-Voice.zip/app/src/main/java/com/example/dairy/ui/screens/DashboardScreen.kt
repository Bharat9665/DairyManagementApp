package com.example.dairy.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.example.dairy.ui.nav.Route

@Composable
fun DashboardScreen(nav: NavHostController) {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("दुग्ध व्यवस्थापन", style = MaterialTheme.typography.headlineSmall)
        Button(onClick = { nav.navigate(Route.Farmers.r) }, modifier = Modifier.fillMaxWidth()) { Text("शेतकरी नोंद") }
        Button(onClick = { nav.navigate(Route.Collections.r) }, modifier = Modifier.fillMaxWidth()) { Text("दूध संकलन") }
        Button(onClick = { nav.navigate(Route.Payments.r) }, modifier = Modifier.fillMaxWidth()) { Text("पेमेंट/उधारी") }
        Button(onClick = { nav.navigate(Route.Reports.r) }, modifier = Modifier.fillMaxWidth()) { Text("रिपोर्ट्स") }
        Button(onClick = { nav.navigate(Route.RateChart.r) }, modifier = Modifier.fillMaxWidth()) { Text("Rate Chart (Fat/SNF)") }
        Button(onClick = { nav.navigate(Route.Statement.r) }, modifier = Modifier.fillMaxWidth()) { Text("Farmer Statement") }
        Button(onClick = { nav.navigate(Route.Backup.r) }, modifier = Modifier.fillMaxWidth()) { Text("Backup/Export (Local/Cloud)") }
    }
}