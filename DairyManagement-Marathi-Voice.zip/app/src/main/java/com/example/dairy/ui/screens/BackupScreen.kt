package com.example.dairy.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.dairy.util.BackupUtils
import com.example.dairy.vm.DairyViewModel
import kotlinx.coroutines.launch
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

@Composable
fun BackupScreen(vm: DairyViewModel) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var lastAction by remember { mutableStateOf("काहीही नाही") }
    var pendingBytes: ByteArray? by remember { mutableStateOf(null) }

    val cloudCreate = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
        uri?.let {
            val bytes = pendingBytes ?: return@let
            BackupUtils.writeToUri(ctx.contentResolver, it, bytes)
            lastAction = "Cloud मध्ये फाइल सेव्ह झाली."
            pendingBytes = null
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Backup/Export (Local/Cloud)", style = MaterialTheme.typography.titleLarge)

        Button(onClick = {
            scope.launch {
                val file = BackupUtils.backupToLocalFile(ctx)
                lastAction = "Local backup: ${file.absolutePath}"
            }
        }, modifier = Modifier.fillMaxWidth()) { Text("Local Backup (JSON)") }

        Button(onClick = {
            scope.launch {
                // Cloud backup using SAF (Google Drive/OneDrive इ. मध्ये सेव्ह होईल)
                val file = BackupUtils.backupToLocalFile(ctx)
                val bytes = file.readBytes()
                pendingBytes = bytes
                cloudCreate.launch("dairy_backup.json")
            }
        }, modifier = Modifier.fillMaxWidth()) { Text("Cloud Backup (JSON)") }

        Button(onClick = {
            scope.launch {
                val file = BackupUtils.exportCsv(ctx, "collections", listOf(listOf("Farmer","Date","Litres")))
                lastAction = "CSV: ${file.absolutePath}"
            }
        }, modifier = Modifier.fillMaxWidth()) { Text("Export CSV") }

        Button(onClick = {
            scope.launch {
                val file = BackupUtils.exportSimplePdf(ctx, "statement", listOf("Dairy Statement", "Demo line 1"))
                lastAction = "PDF: ${file.absolutePath}"
            }
        }, modifier = Modifier.fillMaxWidth()) { Text("Export PDF") }

        Text("स्थिती: " + lastAction)
    }
}