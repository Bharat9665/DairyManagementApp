package com.example.dairy.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.dairy.data.entity.RateSlab
import com.example.dairy.vm.DairyViewModel

@Composable
fun RateChartScreen(vm: DairyViewModel) {
    val slabs by vm.rateSlabs.collectAsState()

    var minFat by remember { mutableStateOf("3.0") }
    var maxFat by remember { mutableStateOf("5.0") }
    var minSnf by remember { mutableStateOf("8.0") }
    var maxSnf by remember { mutableStateOf("9.5") }
    var rate by remember { mutableStateOf("34.0") }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Rate Chart (Fat/SNF)", style = MaterialTheme.typography.titleLarge)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(minFat, { minFat = it }, label = { Text("Min Fat") }, modifier = Modifier.weight(1f))
            OutlinedTextField(maxFat, { maxFat = it }, label = { Text("Max Fat") }, modifier = Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(minSnf, { minSnf = it }, label = { Text("Min SNF") }, modifier = Modifier.weight(1f))
            OutlinedTextField(maxSnf, { maxSnf = it }, label = { Text("Max SNF") }, modifier = Modifier.weight(1f))
        }
        OutlinedTextField(rate, { rate = it }, label = { Text("Rate ₹/L") })
        Button(onClick = {
            val s = RateSlab(
                minFat = minFat.toDoubleOrNull()?:return@Button,
                maxFat = maxFat.toDoubleOrNull()?:return@Button,
                minSnf = minSnf.toDoubleOrNull()?:return@Button,
                maxSnf = maxSnf.toDoubleOrNull()?:return@Button,
                ratePerLitre = rate.toDoubleOrNull()?:return@Button
            )
            vm.saveRateSlab(s)
        }) { Text("Add Slab") }

        Divider()
        Text("Existing Slabs")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(slabs) { s ->
                ElevatedCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) {
                    Text("Fat ${s.minFat}-${s.maxFat}, SNF ${s.minSnf}-${s.maxSnf}")
                    Text("Rate: ₹${s.ratePerLitre}/L")
                } }
            }
        }
    }
}