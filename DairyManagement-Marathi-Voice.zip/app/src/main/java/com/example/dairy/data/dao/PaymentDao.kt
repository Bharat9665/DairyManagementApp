package com.example.dairy.data.dao

import androidx.room.*
import com.example.dairy.data.entity.Payment
import kotlinx.coroutines.flow.Flow

@Dao
interface PaymentDao {
    @Query("SELECT * FROM payments WHERE farmerId=:farmerId ORDER BY date DESC")
    fun forFarmer(farmerId: Long): Flow<List<Payment>>

    @Query("SELECT * FROM payments WHERE date BETWEEN :start AND :end AND farmerId=:farmerId ORDER BY date DESC")
    suspend fun listForFarmer(start: Long, end: Long, farmerId: Long): List<Payment>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(p: Payment): Long
}