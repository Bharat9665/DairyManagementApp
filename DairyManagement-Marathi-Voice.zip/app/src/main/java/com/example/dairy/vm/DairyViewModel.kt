package com.example.dairy.vm

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.dairy.data.AppDatabase
import com.example.dairy.data.entity.*
import com.example.dairy.repo.DairyRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class DairyViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = DairyRepository(AppDatabase.get(app))

    val farmers: StateFlow<List<Farmer>> = repo.farmers()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val rateSlabs: StateFlow<List<RateSlab>> = repo.rateSlabs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun computeRate(fat: Double, snf: Double, defaultRate: Double): Double {
        val s = rateSlabs.value.firstOrNull { fat in it.minFat..it.maxFat && snf in it.minSnf..it.maxSnf }
        return s?.ratePerLitre ?: defaultRate
    }

    fun addOrUpdateFarmer(name: String, phone: String?, village: String?, rate: Double) = viewModelScope.launch {
        repo.upsertFarmer(Farmer(name = name, phone = phone, village = village, ratePerLitre = rate))
    }

    fun addCollection(farmerId: Long, date: Long, shift: String, fat: Double, snf: Double, litres: Double) = viewModelScope.launch {
        repo.addCollection(MilkCollection(farmerId = farmerId, date = date, shift = shift, fat = fat, snf = snf, litres = litres))
    }

    fun addPayment(farmerId: Long, date: Long, amount: Double, note: String?) = viewModelScope.launch {
        repo.addPayment(Payment(farmerId = farmerId, date = date, amount = amount, note = note))
    }

    fun saveRateSlab(s: RateSlab) = viewModelScope.launch { repo.saveRateSlab(s) }
    fun deleteRateSlab(s: RateSlab) = viewModelScope.launch { repo.deleteRateSlab(s) }

    suspend fun listCollectionsForFarmer(start: Long, end: Long, farmerId: Long) =
        repo.listCollectionsForFarmer(start, end, farmerId)
    suspend fun listPaymentsForFarmer(start: Long, end: Long, farmerId: Long) =
        repo.listPaymentsForFarmer(start, end, farmerId)
    suspend fun listFarmers() = repo.listFarmers()
    suspend fun listRateSlabs() = repo.listRateSlabs()
}