
package com.example.dairy.ui.screens

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.dairy.vm.DairyViewModel
import java.util.*

@Composable
fun PaymentsScreen(vm: DairyViewModel) {
    val farmers by vm.farmers.collectAsState()
    val context = LocalContext.current
    var idx by remember { mutableStateOf(0) }

    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (!granted) Toast.makeText(context, "मायक्रोफोनची परवानगी दिली पाहिजे", Toast.LENGTH_SHORT).show()
    }

    val amountLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val matches = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val text = matches?.getOrNull(0) ?: ""
            val num = text.filter { it.isDigit() || it=='.' }
            if (num.isNotBlank()) amount = num
        }
    }
    val noteLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val matches = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val text = matches?.getOrNull(0) ?: ""
            note = text
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("पेमेंट/उधारी नोंद")
        if (farmers.isNotEmpty()) {
            Text("शेतकरी: ${'$'}{farmers[idx].name}")
            Slider(value = idx.toFloat(), onValueChange = { idx = it.toInt().coerceIn(0, farmers.lastIndex) }, valueRange = 0f..farmers.lastIndex.toFloat())
        } else Text("कृपया आधी शेतकरी जोडा")

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(amount, { amount = it }, label = { Text("रक्कम (₹)") }, modifier = Modifier.weight(1f))
            IconButton(onClick = {
                permLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
                    putExtra(RecognizerIntent.EXTRA_PROMPT, "रक्कम बोला")
                }
                amountLauncher.launch(intent)
            }) { Icon(Icons.Default.Mic, contentDescription = "voice") }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(note, { note = it }, label = { Text("टीप") }, modifier = Modifier.weight(1f))
            IconButton(onClick = {
                permLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "mr-IN")
                    putExtra(RecognizerIntent.EXTRA_PROMPT, "टीप बोला")
                }
                noteLauncher.launch(intent)
            }) { Icon(Icons.Default.Mic, contentDescription = "voice") }
        }
        Button(onClick = {
            val a = amount.toDoubleOrNull() ?: return@Button
            val farmerId = farmers.getOrNull(idx)?.id ?: return@Button
            vm.addPayment(farmerId, Date().time, a, note.ifBlank { null })
            amount = ""; note = ""
        }) { Text("सेव्ह") }
    }
}
