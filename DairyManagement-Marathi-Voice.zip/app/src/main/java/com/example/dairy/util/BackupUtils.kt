package com.example.dairy.util

import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import androidx.activity.result.contract.ActivityResultContracts
import com.example.dairy.data.AppDatabase
import com.example.dairy.data.entity.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.io.FileOutputStream

object BackupUtils {
    @kotlinx.serialization.Serializable
    data class Dump(
        val farmers: List<Farmer>,
        val collections: List<MilkCollection>,
        val payments: List<Payment>,
        val rateSlabs: List<RateSlab>
    )

    suspend fun backupToLocalFile(context: Context): File = withContext(Dispatchers.IO) {
        val db = AppDatabase.get(context)
        val farmers = db.farmerDao().list()
        val slabs = db.rateSlabDao().list()
        // simple overall dump (no date filter)
        val collections = db.collectionDao().listForFarmer(Long.MIN_VALUE, Long.MAX_VALUE, -1L).filter { true }
        val payments = db.paymentDao().listForFarmer(Long.MIN_VALUE, Long.MAX_VALUE, -1L).filter { true }
        val dump = Dump(farmers, collections, payments, slabs)
        val json = Json.encodeToString(dump)
        val dir = File(context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "backup")
        dir.mkdirs()
        val file = File(dir, "dairy_backup.json")
        file.writeText(json)
        file
    }

    suspend fun exportCsv(context: Context, fileName: String, rows: List<List<String>>): File = withContext(Dispatchers.IO) {
        val dir = File(context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "exports")
        dir.mkdirs()
        val file = File(dir, "$fileName.csv")
        file.printWriter().use { out -> rows.forEach { out.println(it.joinToString(",")) } }
        file
    }

    suspend fun exportSimplePdf(context: Context, fileName: String, lines: List<String>): File = withContext(Dispatchers.IO) {
        val document = android.graphics.pdf.PdfDocument()
        val pageInfo = android.graphics.pdf.PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = document.startPage(pageInfo)
        val canvas = page.canvas
        val paint = android.graphics.Paint()
        var y = 40
        lines.forEach {
            canvas.drawText(it, 30f, y.toFloat(), paint)
            y += 20
        }
        document.finishPage(page)
        val dir = File(context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "exports")
        dir.mkdirs()
        val file = File(dir, "$fileName.pdf")
        document.writeTo(FileOutputStream(file))
        document.close()
        file
    }

    fun createDocumentIntent(fileName: String, mime: String): Intent {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT)
        intent.addCategory(Intent.CATEGORY_OPENABLE)
        intent.type = mime
        intent.putExtra(Intent.EXTRA_TITLE, fileName)
        return intent
    }

    fun writeToUri(cr: ContentResolver, uri: Uri, bytes: ByteArray) {
        cr.openOutputStream(uri)?.use { it.write(bytes) }
    }
}