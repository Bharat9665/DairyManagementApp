
package com.example.dairy.ui.screens

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.dairy.vm.DairyViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun ReportsScreen(vm: DairyViewModel) {
    val sdf = remember { SimpleDateFormat("dd MMM, yyyy", Locale.getDefault()) }
    val today = remember { Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY,0); set(Calendar.MINUTE,0); set(Calendar.SECOND,0); set(Calendar.MILLISECOND,0) } }
    val start = today.timeInMillis

    val farmers by vm.farmers.collectAsState()
    val context = LocalContext.current

    var idx by remember { mutableStateOf(0) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (!granted) Toast.makeText(context, "मायक्रोफोनची परवानगी दिली पाहिजे", Toast.LENGTH_SHORT).show()
    }

    val farmerSelectLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val matches = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val text = matches?.getOrNull(0) ?: ""
            // try to match name approximately
            val found = farmers.indexOfFirst { it.name.contains(text, ignoreCase = true) }
            if (found >= 0) idx = found
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("रिपोर्ट्स", style = MaterialTheme.typography.titleLarge)
        Text("आजची तारीख: ${'$'}{sdf.format(Date(start))}")

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("शेतकरी: ${'$'}{if (farmers.isNotEmpty()) farmers[idx].name else "-"}", modifier = Modifier.weight(1f))
            IconButton(onClick = {
                permLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "mr-IN")
                    putExtra(RecognizerIntent.EXTRA_PROMPT, "शेतकऱ्याचं नाव बोला")
                }
                farmerSelectLauncher.launch(intent)
            }) { Icon(Icons.Default.Mic, contentDescription = "voice") }
        }

        Text("नोंदवलेले शेतकरी: ${'$'}{farmers.size}")
        Text("(TIP) Use voice to choose farmer for statement.")
    }
}
