package com.example.dairy.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.dairy.vm.DairyViewModel
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun StatementScreen(vm: DairyViewModel) {
    val scope = rememberCoroutineScope()
    val farmers by vm.farmers.collectAsState()
    var idx by remember { mutableStateOf(0) }

    val cal = remember { Calendar.getInstance() }
    cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
    var start by remember { mutableStateOf(cal.timeInMillis - 6L*24*60*60*1000) }
    var end by remember { mutableStateOf(cal.timeInMillis + 24*60*60*1000 - 1) }
    val sdf = remember { SimpleDateFormat("dd MMM yyyy", Locale.getDefault()) }

    var summary by remember { mutableStateOf("स्टेटमेंट काढण्यासाठी बटण दाबा") }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Farmer Statement", style = MaterialTheme.typography.titleLarge)
        if (farmers.isNotEmpty()) {
            Text("शेतकरी: ${farmers[idx].name}")
            Slider(value = idx.toFloat(), onValueChange = { idx = it.toInt().coerceIn(0, farmers.lastIndex) }, valueRange = 0f..farmers.lastIndex.toFloat())
        }
        Text("From: ${sdf.format(Date(start))}  To: ${sdf.format(Date(end))}")
        Button(onClick = {
            scope.launch {
                val f = farmers.getOrNull(idx) ?: return@launch
                val cols = vm.listCollectionsForFarmer(start, end, f.id)
                val pays = vm.listPaymentsForFarmer(start, end, f.id)
                val litres = cols.sumOf { it.litres }
                val rate = f.ratePerLitre
                val amount = cols.sumOf { it.litres * rate }
                val paid = pays.sumOf { it.amount }
                val due = amount - paid
                summary = "लिटर: %.2f, रक्कम: ₹%.2f, पेमेंट: ₹%.2f, बाकी: ₹%.2f".format(litres, amount, paid, due)
            }
        }) { Text("काढा") }
        Text(summary)
    }
}