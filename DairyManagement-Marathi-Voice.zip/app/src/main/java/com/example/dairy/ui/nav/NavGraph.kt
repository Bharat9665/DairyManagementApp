package com.example.dairy.ui.nav

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.dairy.ui.screens.*
import com.example.dairy.vm.DairyViewModel

sealed class Route(val r: String) {
    data object Dashboard: Route("dashboard")
    data object Farmers: Route("farmers")
    data object Collections: Route("collections")
    data object Payments: Route("payments")
    data object Reports: Route("reports")
    data object RateChart: Route("ratechart")
    data object Statement: Route("statement")
    data object Backup: Route("backup")
}

@Composable
fun AppNavGraph(vm: DairyViewModel, nav: NavHostController = rememberNavController()) {
    NavHost(navController = nav, startDestination = Route.Dashboard.r) {
        composable(Route.Dashboard.r) { DashboardScreen(nav) }
        composable(Route.Farmers.r) { FarmersScreen(vm) }
        composable(Route.Collections.r) { CollectionsScreen(vm) }
        composable(Route.Payments.r) { PaymentsScreen(vm) }
        composable(Route.Reports.r) { ReportsScreen(vm) }
        composable(Route.RateChart.r) { RateChartScreen(vm) }
        composable(Route.Statement.r) { StatementScreen(vm) }
        composable(Route.Backup.r) { BackupScreen(vm) }
    }
}