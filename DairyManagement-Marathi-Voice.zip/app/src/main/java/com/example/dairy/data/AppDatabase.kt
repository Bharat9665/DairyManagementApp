package com.example.dairy.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.dairy.data.dao.*
import com.example.dairy.data.entity.*

@Database(
    entities = [Farmer::class, MilkCollection::class, Payment::class, RateSlab::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun farmerDao(): FarmerDao
    abstract fun collectionDao(): MilkCollectionDao
    abstract fun paymentDao(): PaymentDao
    abstract fun rateSlabDao(): RateSlabDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null
        fun get(context: Context): AppDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "dairy.db"
            ).fallbackToDestructiveMigration().build().also { INSTANCE = it }
        }
    }
}